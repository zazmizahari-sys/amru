# AMRU Operations Web App

Web aplikasi pengurusan operasi untuk **AMRU** (7 butik & 33 staf), merangkumi:
1. **Ringkasan**: Paparan keseluruhan prestasi jualan & notifikasi tugasan.
2. **Sales**: Rekod jualan harian & pencapaian sasaran bulanan.
3. **Marketing & Content**: Bank idea content, pengurusan kempen, aliran kerja penghasilan content.
4. **Tugas**: Senarai tugasan mengikut pasukan (Staf Butik, Content Creator, Marketing).

## Cara Guna / Guna di GitHub
1. Muat naik fail `index.html` ini ke dalam repositori GitHub anda.
2. Pergi ke **Settings** > **Pages** di GitHub.
3. Di bahagian **Build and deployment**, pilih branch `main` (atau `master`) dan folder `/ (root)`, kemudian klik **Save**.
4. GitHub Pages akan memberikan pautan URL web app anda untuk diakses terus dari telefon pintar atau komputer!
